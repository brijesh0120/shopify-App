<?php
require_once("inc/functions.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class generate_token{
    public $conn;
    
    function __construct(){

        $servername = "localhost";
        $username = "root";
        $password = "";
        $this->conn = new PDO("mysql:host=$servername;dbname=App", $username, $password);
       
    }

    public function getAccessToken($code='',$shop='')
    {

    $shop = $_GET['shop'] ?? 'brijesh-singh1.myshopify.com';

        $sql= "SELECT * FROM app_setting";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $app = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql2= "SELECT * FROM user_setting WHERE shop= :shop";
        $stmt2 = $this->conn->prepare($sql2);
        $stmt2->execute([':shop'=>$shop]);
        $user = $stmt2->fetch(PDO::FETCH_ASSOC);

        if($code=='')
        {
            $code = $user['code'];
        }
        
        // Set variables for our request
        $query = array(
            "client_id" => $app['client_id'], // Your API key
            "client_secret" => $app['secret_id'], // Your app credentials (secret key)
            "code" => $code // Grab the access key from the URL
        );

        // Generate access token URL
        $access_token_url = "https://" . $app['shop'] . "/admin/oauth/access_token";

        // Configure curl client and execute request
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $access_token_url);
        curl_setopt($ch, CURLOPT_POST, count($query));
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
        $result = curl_exec($ch);
        curl_close($ch);

        // Store the access token
        $result = json_decode($result, true);
        

        if(isset($result['access_token']))
        {
            $access_token = $result['access_token'];

            $sql = 'UPDATE user_setting SET payment_status = :payment_status, access_token = :access_token WHERE shop = :shop';
            $statement = $this->conn->prepare($sql);
            $statement->execute([':payment_status'=>0,':access_token'=>$access_token, ':shop'=>$shop]);

            $this->recurring_application_charge($access_token,$app['shop']);
        }
        else
        {
           // print_r($result);
            echo "<br>access_token not found";
        }
        die;

    }

    public function recurring_application_charge($token,$shop)
    {

        $array = array(
            'recurring_application_charge' => array(
                'name' => 'Example Plan',
                'test' => true,  //remove this line before sending to app store
                'price' => 15.0,
                'return_url' => "http://localhost/test-app/generate_token.php"
            )
        );
        
        $charge = shopify_call($token, $shop, "/admin/api/2019-10/recurring_application_charges.json", $array, 'POST');

        $charge = json_decode($charge['response'], JSON_PRETTY_PRINT);

        $confirm_url = $charge['recurring_application_charge']['confirmation_url'];
        $charge_id = $charge['recurring_application_charge']['id'];

        // echo $charge_id;
        // die;

        if(isset($confirm_url))
        {
            $sql = 'UPDATE user_setting SET payment_status = :payment_status,charge_id = :charge_id WHERE shop = :shop';
            $statement = $this->conn->prepare($sql);
            $statement->execute([':payment_status'=>0,':charge_id'=>$charge_id,':shop'=>$shop]);
        }
        header("Location: " . $confirm_url);
        die();

    }

    public function activateCharge($charge_id)
    {
            $charge_id = $_GET['charge_id'];
    
            $sql= "SELECT * FROM user_setting WHERE charge_id = :charge_id";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':charge_id'=>$charge_id]);
            $getCharge = $stmt->fetch(PDO::FETCH_ASSOC);

            $sql1= "SELECT * FROM app_setting";
            $stmt1 = $this->conn->prepare($sql1);
            $stmt1->execute();
            $GetApp = $stmt1->fetch(PDO::FETCH_ASSOC);
            
            $shop = $getCharge['shop'];
            $app_name = $GetApp['app_name'];

            $array = array(
                'recurring_application_charge' => array(
                    "id" => $charge_id,
                    "name" => "Example Plan",
                    "api_client_id" => $GetApp['client_id'],
                    "price" => "15.00",
                    "status" => "accepted",
                    "return_url" => "$shop/admin/apps/$app_name",
                    "billing_on" => null,
                    "test" => true,
                    "activated_on" => null,
                    "trial_ends_on" => null,
                    "cancelled_on" => null,
                    "trial_days" => 10,
                    "decorated_return_url" => "$shop/admin/apps/$app_name/?charge_id=" . $charge_id
                )
            );
        
            $activate = shopify_call($getCharge['access_token'], $shop, "/admin/api/2019-10/recurring_application_charges/".$charge_id."/activate.json", $array, 'POST');
            $activate = json_decode($activate['response'], JSON_PRETTY_PRINT);
            
            if($activate['recurring_application_charge']['status']=='active')
            {
                $sql = 'UPDATE user_setting SET payment_status = :payment_status WHERE shop = :shop';
                $statement = $this->conn->prepare($sql);
                $statement->execute([':payment_status'=>2,':shop'=>$shop]);

                //echo "$shop/admin/apps/$app_name";
                header("location:https://$shop/admin/apps/$app_name");

            }
            else
            {
                $sql = 'UPDATE user_setting SET payment_status = :payment_status WHERE shop = :shop';
                $statement = $this->conn->prepare($sql);
                $statement->execute([':payment_status'=>1,':shop'=>$shop]);

                print_r($activate);
            }
          
 

    }
}
$token = new generate_token();
if(isset($_GET['code']))
{
    $token->getAccessToken($_GET['code'],$_GET['shop']);
}
elseif(isset($_GET['charge_id']))
{
    $token->activateCharge($_GET['charge_id']);
    //redirect
}


?>