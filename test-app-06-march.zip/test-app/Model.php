<?php
require_once ("DB.php");
require_once("inc/functions.php");
class Mymodel {

    public $conn;
    
    function __construct() {

        $servername = "localhost";
        $username = "root";
        $password = "";

        $this->conn = new PDO("mysql:host=$servername;dbname=App", $username, $password);
    }

    function checkUser($shop)
    {   
            $sql= "SELECT * FROM user_setting WHERE shop=:shop";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':shop'=>$shop]);
            
            $count = $stmt->rowCount();
            if($count==0)
            {
                $data = ['hmac'=>$_GET['hmac'], 'host'=>$_GET['host'], 'shop'=>$shop];
                $sql = "INSERT INTO user_setting (hmac, host, shop) VALUES (:hmac, :host, :shop)";
                $stmt= $this->conn->prepare($sql);
                $stmt->execute($data);
            }

                $sql= "SELECT * FROM user_setting WHERE shop=:shop";
                $stmt = $this->conn->prepare($sql);
                $stmt->execute([':shop'=>$shop]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                return $user;
    }

    function getPayment($shop)
    {
       $user = $this->checkUser($shop);
       return $user['payment_status'];
    }

    function installApp($shop)
    {
        $sql= "SELECT * FROM app_setting";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $app = $stmt->fetch(PDO::FETCH_ASSOC);

        $api_key = $app['client_id'];
        $scopes = $app['scope'];
        $redirect_uri = $app['redirect_url'];
        
        // Build install/approval URL to redirect to
        $install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);
        
        // Redirect
        header("Location: " . $install_url);
        die();
    

    }

    public function getProduct($shop)
    {
        $sql2= "SELECT * FROM user_setting WHERE shop= :shop";
        $stmt2 = $this->conn->prepare($sql2);
        $stmt2->execute([':shop'=>$shop]);
        $user = $stmt2->fetch(PDO::FETCH_ASSOC);

        $products = shopify_call($user['access_token'], $shop, "/admin/api/2019-10/products.json", array(), 'GET');

        $products = json_decode($products['response'], JSON_PRETTY_PRINT);
        return $products;
    }

}
?>