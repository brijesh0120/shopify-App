<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('libs/Smarty.class.php');
require_once 'DB.php'; 
require_once 'Model.php'; 
require_once 'generate_token.php'; 

class Home {

    public $model;
    public $conn;
    public $generateToken;
    function __construct() {
        $this->smarty = new Smarty;
        $this->smarty->template_dir = "templates";
        $this->smarty->compile_dir = "templates_c";
        $this->model = new Mymodel(); 
        $this->generateToken = new generate_token();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $this->conn = new PDO("mysql:host=$servername;dbname=App", $username, $password);
       

        $this->model->checkUser($_GET['shop']);
        $active = $this->model->getPayment($_GET['shop']);


        if($active==0)
        {
            $this->model->installApp($_GET['shop']);
        }
        elseif($active==1)
        {
            $this->generateToken->getAccessToken();
        }
        elseif($active==2)
        {
            $this->welcome();
            
            // if(isset($_GET['hmac']))
            // {
            //     $sql1= "SELECT * FROM app_setting";
            //     $stmt1 = $this->conn->prepare($sql1);
            //     $stmt1->execute();
            //     $GetApp = $stmt1->fetch(PDO::FETCH_ASSOC);
                
            //     $shop = $_GET['shop'];
            //     $app_name = $GetApp['app_name'];   
            //     header("location:https://$shop/admin/apps/$app_name");
            // }
            // else
            // {
            //     $this->welcome();
            // }
            
        }

    }
  
   function welcome()
   { ?>
   <script src="https://unpkg.com/@shopify/app-bridge"></script>

    <script>
     var AppBridge = window['app-bridge'];
     var actions = window['app-bridge'].actions;
     var product = [];
        const config = {
        apiKey: "ab82efef3ed3c96b92b4db9bf576a544",
        host: new URLSearchParams(location.search).get("host"),
        forceRedirect: true
        };

        const app = AppBridge.createApp(config);

        const ResourcePicker = AppBridge.actions.ResourcePicker;


        const picker = ResourcePicker.create(app, {
        resourceType: ResourcePicker.ResourceType.Product
        });

        picker.subscribe(ResourcePicker.Action.SELECT, (payload) => {

            payload.selection.forEach(function (item) {
                product.push(item.id );
                
        });
        product = product.toString();
        console.log(product);
        const url = "http://localhost/test-app/Product.php?"+product;
        let xhr = new XMLHttpRequest()
        xhr.open('POST', url, true)
        xhr.setRequestHeader('Content-type', 'application/json; charset=UTF-8')
        xhr.send({product});
        xhr.onload = function () {
            if(xhr.status === 201) {
                console.log("Post successfully created!") 
            }
        }
        // console.log(payload.selection);
        });

        picker.dispatch(ResourcePicker.Action.OPEN);



    </script>


     <?php   
        $data = $this->model->getProduct($_GET['shop']);
        // echo "<pre>";
        // print_r($data['products']);
        // die;
        $this->smarty->assign('title','Welcome');
        $this->smarty->assign('data',$data['products']);
        $this->smarty->display('index.tpl');
   } 


}

$class = new Home();



?>