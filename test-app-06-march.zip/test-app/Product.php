<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class Product {
    public function addProduct()
    {
        $data = $_GET;
        print_r(explode(',',$data['ids']));
    }
}
$obj = new Product();
$data = $obj->addProduct();

?>